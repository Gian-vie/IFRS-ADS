// Página pública simples de boas-vindas.
export default function Home() {
  return (
    <section className="card">
      <h1>Home</h1>
      <p>Bem-vindo! Esta é uma rota pública da aplicação.</p>
    </section>
  );
}
