-- Cria o banco de dados se não existir
CREATE DATABASE IF NOT EXISTS projeto_api_db CHARACTER SET utf8mb4 COLLATE
utf8mb4_unicode_ci;
-- Usa o banco de dados
USE projeto_api_db;