-- Usa o banco
USE projeto_api_db;
-- Inserção de dados fictícios
INSERT INTO users (name, email) VALUES
('João da Silva', 'joao@example.com'),
('Maria Oliveira', 'maria@example.com');