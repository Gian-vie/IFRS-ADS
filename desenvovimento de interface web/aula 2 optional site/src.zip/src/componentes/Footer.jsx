// Componente Footer
function Footer({value}) {
    return (
        <footer>
            <p>{value} aaaa</p>
        </footer>
    );
}

export default Footer;